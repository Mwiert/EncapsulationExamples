﻿using System;

namespace ProgDilDO
{
    class Program
    {
        static void Main(string[] args)
        {
            int RanSay;
            string  RanDep, RandDoctor;

            Hasta hasta = new Hasta();
            int verify, check;
            string loginType;
            Console.WriteLine("Hastane Panel için Panel\nKontrol için Kontrol\nYaziniz");
            loginType = Console.ReadLine();
            if (loginType == "PANEL" ||loginType=="Panel"||loginType=="panel")
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                }
                Console.WriteLine("-----------------------------------------------------HASTANE PANELİ-----------------------------------------------------");
                Hastane hastane = new Hastane();
                Console.WriteLine("Hastane Adı Giriniz");
                hastane.HastaneAdi = Console.ReadLine();
                Console.WriteLine("Hastane Adresini Giriniz");
                hastane.HastaneAdresi = Console.ReadLine();
                Console.WriteLine("Hastane Telefon No Giriniz");
                hastane.HastaneTelefonNo = Console.ReadLine();

                Console.WriteLine("Departman Adi Giriniz.");
                hastane.DepartmanAdi = Console.ReadLine();

                Console.WriteLine("Departman Başhekim Adini Giriniz.");
                hastane.DepoartmanBashekimAdi = Console.ReadLine();

                Console.WriteLine("Departman Çalışan Sayisini Giriniz.");
                hastane.DepartmanCalisanSayisi = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Girdiğiniz Departman :{0}\nGirdiğiniz Departmanın BaşHekimi :{1}\nGirdiğiniz Departmanın Çalışan Sayısı :{2}\n", hastane.DepartmanAdi, hastane.DepoartmanBashekimAdi, hastane.DepartmanCalisanSayisi);
                Console.WriteLine("Gösterilen Bilgiler Doğru ise 1'i Başka bir Sayi Yazınız");
                verify = Convert.ToInt32(Console.ReadLine());
                if (verify == 1)
                {
                    Console.WriteLine("Girdiğiniz Bilgilerin doğruluğunu ONAYLADINIZ.");
                }
                else
                {
                    Console.WriteLine("Girdiğiniz Bilgilerin doğruluğunu ONAYLAMADINIZ.");
                }
            }
            else if (loginType == "KONTROL" || loginType == "Kontrol" || loginType == "kontrol")
            {
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                }
                Console.WriteLine("-----------------------------------------------------KONTROL PANELİ-----------------------------------------------------");
                Console.WriteLine("\n\n\n\n\n");
                Console.WriteLine("Randevu Departmanının Adını\nRandevu Alınan Doktorun adını\nDoktora ait Randevu Sayısını Giriniz");
                
                RanDep = Console.ReadLine();
                RandDoctor =Console.ReadLine();
                RanSay = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Bilgileri Yazdırmak için 1\nÇıkmak için Başka bir Sayi Tuşlayınız.");
                check =Convert.ToInt32(Console.ReadLine());
                if (check==1)
                {
                    Console.WriteLine("Girilen Bilgiler\nRandevu Departmanının Adı:{0}\nRandevu Alınan Doktorun adı:{1}\nDoktora ait Randevu Sayısı:{2}", hasta.RandavuSayisi(RanSay, RanDep, RandDoctor).Item3, hasta.RandavuSayisi(RanSay, RanDep, RandDoctor).Item2, hasta.RandavuSayisi(RanSay, RanDep, RandDoctor).Item1);
                }
            }
            else
            {
                Console.WriteLine("Hatalı Tuşlama yaptınız");
            }
            
        }
    }
}
