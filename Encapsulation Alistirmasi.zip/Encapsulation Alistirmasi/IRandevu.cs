﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgDilDO
{
    public interface IRandevu
    {
        //field
        int RandevuSayisiAylik { get; set; }
        string RandevuAlinanDepartmanlar { get; set; }
        string RandDoctoru { get;set; }

        //metot
        (int,string,string) RandavuSayisi (int RandSayi,string departmanAdi,string DoktorAdi );
        string RADepartman(string DepartmanAdi);
    }
}
