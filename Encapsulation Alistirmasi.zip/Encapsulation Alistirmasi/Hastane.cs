﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgDilDO
{
    //kalıtım kullandık
    internal class Hastane : HastaneDepartmanBilgileri
    {
        //Field (ALAN)
        private string HospitalName;
        private string HospitalAdress;
        private string HospitalTelNo;
        private string HastaneShownEmail;
        //property(özellikleri)

        public string HastaneAdi {
            set
            {
                this.HospitalName = value;
            }
            get
            {
                return this.HospitalName;
            }
        }
        public string HastaneAdresi {
            set
            {
                this.HospitalAdress = value;
            }
            get
            {
                return this.HospitalAdress;
            }
        }
        public string HastaneTelefonNo {
            set
            {
                this.HospitalTelNo = value;
            }
            get
            {
                return this.HospitalTelNo;
            }
        }

        public string HastaneEmail {
            set
            {
                this.HastaneShownEmail = value;
            }
            get
            {
                return this.HastaneShownEmail;
            }
        }
    }
}
