﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgDilDO
{
    class HastaneDepartmanBilgileri
    {
        private string DepartmanName;
        private string DepoartmanHeadDocName;
        private int DepartmanWorkerNumber;

        public string DepartmanAdi
        {
            set
            {
                this.DepartmanName = value;
            }
            get
            {
                return this.DepartmanName;
            }
        }
        public string DepoartmanBashekimAdi
        {
            set
            {
                this.DepoartmanHeadDocName = value;
            }
            get
            {
                return this.DepoartmanHeadDocName;
            }
        }
        public int DepartmanCalisanSayisi
        {
            set
            {
                this.DepartmanWorkerNumber = value;
            }
            get
            {
                return this.DepartmanWorkerNumber;
            }
        }
    }
}
