﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgDilDO
{
    class Hasta : IRandevu
    {
        int _RandevuSayisi;
        string _RandevuRepartman;
        string _RandDoctor;
        public int RandevuSayisiAylik { get { return _RandevuSayisi; } set { _RandevuSayisi = value; } }
        public string RandevuAlinanDepartmanlar { get { return _RandevuRepartman; } set { _RandevuRepartman = value; } }
        public string RandDoctoru { get { return _RandDoctor; } set { _RandDoctor = value; } }

        public string RADepartman(string DepartmanAdi)
        {
            _RandevuRepartman=DepartmanAdi ;
            return DepartmanAdi;
        }

        public (int,string,string) RandavuSayisi(int RandSayi,string departmanAdi, string DoktorAdi)
        {
            _RandevuSayisi = RandSayi;
            _RandevuRepartman = departmanAdi;
            _RandDoctor= DoktorAdi;
            return (RandSayi,departmanAdi,DoktorAdi);
        }
    }
}
